#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <pic32mx.h>
#include "main.h"
#include "initGame.h"
#include "objekt.h"


void initGame(void)
{
    int i = 0;
    int bredd = 24;
    while(i!=10)
    {
        enemies1[i].x = bredd;   //x koordinat
        enemies1[i].y = 2;   //y koordinat
        enemies1[i].z = 1;   //0 = alive, 1 = dead
        
        enemies2[i].x = bredd;   //x koordinat
        enemies2[i].y = 6;   //y koordinat
        enemies2[i].z = 1;   //0 = alive, 1 = dead
        
        enemies3[i].x = bredd;   //x koordinat
        enemies3[i].y = 10;   //y koordinat
        enemies3[i].z = 1;   //0 = alive, 1 = dead
        
        bredd += 8;
        i++;
    }
}



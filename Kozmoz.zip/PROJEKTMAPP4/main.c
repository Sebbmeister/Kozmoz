#include <stdint.h>
#include <stdio.h>
#include <pic32mx.h>
#include "project.h"
#include "display.h"
#include "assets.h"
#include "main.h"
#include "objekt.h"
#include "funktioner.h"
#include "define.h"
#include "initGame.h"
#include "initStartScreen.h"
#include "initEndScreen.h"

int main(void)
{
    int stopper = 0;
    if(stopper == 0)
    {
        initGame();
        spiinit();
        display_init();
        display_update();
        startingScreen();
        delay(20);
        stopper = 1;
    }
    
    while (1)
    {
        TRISE = TRISE & 0xFF00;
        TRISD = TRISD & 0x00F0;
        
        initGame();
        spiinit();
        display_init();
        display_update();
        menu();
        huvudkoden();
        delay(100);
    }
}



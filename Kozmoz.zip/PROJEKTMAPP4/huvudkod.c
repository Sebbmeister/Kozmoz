#include <stdint.h>
#include <stdio.h>
#include <pic32mx.h>
#include "project.h"
#include "display.h"
#include "assets.h"
#include "main.h"
#include "objekt.h"
#include "funktioner.h"
#include "define.h"
#include "initGame.h"
#include "initStartScreen.h"

#define START_SCREEN    0
#define MENU_ONE        1
#define MENU_TWO        2
#define MENU_THREE      3

int HP = 8;
int highscore = 0;
int button = 1;
int z;
int select = 0;
int stopper = 0;
int pos = 2;
char score1[3] = {'M', 'U', 'M'};

int hsArr[3] = {0, 0, 0};


void delay(int k)
{
    int j = 0;
    while (k > 0){
        for (j = 0; j < 7500; j++){
        }
        k--;
    }
}

void user_isr()
{
    return;
}

void startingScreen()
{
    while(1)
    {
        renderScreen(start);
        int btn3 = getbtns();
     
        if(btn3 == 1 || btn3 == 2 || btn3 == 4)
        {
            break;
        }
     
     }
}


void huvudkoden()
{

    int markerarStop1 = 0;
    int markerarStop2 = 0;
    int markerarStop3 = 0;

    
    int timecounter1 = 0;
    int timecounter2 = 0;
    int timecounter3 = 0;
    int timecounter4 = 0;
    
    int timematch1 = 0;
    int timematch2 = 0;
    
    int markerarIndex1 = 0;
    int markerarIndex2 = 0;
    int markerarIndex3 = 0;
    
    int counter = 0;
    int counter1 = 0;
    
    int screen = 0;
    int bulletActivate = 0;
    int enemyBulletActivate1 = 0;
    int enemyBulletActivate2 = 0;
    int enemyBulletActivate3 = 0;
    int MAX_X = 128;
    int enemiesHit = 0;
    
    int stop1 = 0;
    int stop2 = 0;
    int stop3 = 0;
    int stop4 = 0;
    
    /*
    /   Revive Enemies
    */
    z = 0;
    while(z!=10)
    {
        enemies1[z].z = 1;   //0 = alive, 1 = dead
        enemies2[z].z = 1;   //0 = alive, 1 = dead
        enemies3[z].z = 1;   //0 = alive, 1 = dead
        z++;
    }
    
        ship.x = 64;
    ship.y = 30;
    
    T2CONSET = 0x70;    //Prescaler 256
    PR2 = 0x7A12;       //Set period register (Beräknat)
    TMR2 = 0;           //Reset clock (clear)
    T2CONSET = 0x8000;  //Starts clock, bit 15(on) set to 1
    
    T4CONSET = 0x60;    //Prescaler 64
    PR4 = 0x927C;      //Set period register (Beräknat)
    TMR4 = 0;           //Reset clock (clear)
    T4CONSET = 0x8000;  //Starts clock, bit 15(on) set to 1
    
    
    while(1)
    {
        
        if (IFS(0) & 0x100)  //IFS(0) biten är satt när TMR2 = PR2 (var 100:e millisekund)
        {
            timecounter1++;
            IFSCLR(0) = 0x100; //reset flag bit
        }
        
        if (IFS(0) & 0x10000)
        {
            timecounter2++;
            IFSCLR(0) = 0x10000; //reset flag bit
        }
        
        /*
        /   "KLOCKA FÖR FIENDERAD 1 (3)"
        */
        if (timecounter1 == 10)
        {
            timecounter1 = 0;
        }
        if (timecounter2 == 10)
        {
            timecounter2 = 0;
        }
        
        
        /*
         /   "KLOCKA FÖR FIENDERAD 2"
         */
        if(timecounter1 == 7 && enemyBulletActivate2 == 0)
        {
            markerarIndex2 = timecounter1;
            enemyBulletActivate2 = 1;
            markerarStop3 = 0;
        }
        
        
        /*
         /   "KLOCKA FÖR FIENDERAD 3"
         */
        if(timecounter1 == 3 && enemyBulletActivate3 == 0)
        {
            markerarIndex3 = timecounter1;
            enemyBulletActivate3 = 1;
            markerarStop2 = 0;
        }
        
        
        /*
         /   "KLOCKA FÖR FIENDERAD 1"
         */
        if (timecounter2 == timecounter1 && enemyBulletActivate1 == 0)
        {
            markerarIndex1 = timecounter1;
            enemyBulletActivate1 = 1;
            markerarStop1 = 0;
        }
        
        
        
        int btn = getbtns();
        
        //Button 4
        if(btn == 4 || btn == 5 || btn == 6 || btn == 7)
        {
            if (ship.x != 5)
            {
                ship.x -= 1;
            }
            /*draw1(ship, enemies1, enemies2, enemies3, enemyBullet1, enemyBullet2, enemyBullet3);*/
            
        }
        
        //Button 3
        if (btn == 2 || btn == 3 || btn == 6 || btn == 7)
        {
            if (ship.x != (MAX_X - 5))
            {
                ship.x += 1;
            }
            /*draw1(ship, enemies1, enemies2, enemies3, enemyBullet1, enemyBullet2, enemyBullet3);*/
        }
        
        //Button 2
        if (btn == 1 || btn == 3 || btn == 5 || btn == 7)
        {
            if (bulletActivate !=1)
            {
                bullet.x = ship.x;
                bullet.y = ship.y;
                bulletActivate = 1;
            }
        }
        
        
        /*
        /   BULLETACTIVATE 1
        */
        if (enemyBulletActivate1 == 1)
        {
            if (enemies3[markerarIndex1].z == 0)
            {
                enemyBulletActivate1 = 0;
                markerarStop1 = 1;
            }
            if(markerarStop1 == 0)
            {
                enemyBullet1.x = enemies3[markerarIndex1].x;
                enemyBullet1.y = enemies3[markerarIndex1].y;
            }
            markerarStop1 = 1;
        }
        
        if (enemyBullet1.y != 32)
        {
            enemyBullet1.y += 1;
        }else
        {
            enemyBulletActivate1 = 0;
            markerarStop1 = 0;
        }
        
        
        /*
         /   BULLETACTIVATE 2
         */
        if (enemyBulletActivate2 == 1)
        {
            if (enemies2[markerarIndex2].z == 0)
            {
                enemyBulletActivate2 = 0;
                markerarStop1 = 2;
            }
            if(markerarStop2 == 0)
            {
                enemyBullet2.x = enemies2[markerarIndex2].x;
                enemyBullet2.y = enemies2[markerarIndex2].y;
            }
            markerarStop2 = 1;
        }
        
        if (enemyBullet2.y != 32)
        {
            enemyBullet2.y += 1;
        }else
        {
            enemyBulletActivate2 = 0;
            markerarStop2 = 0;
        }
        
        
        /*
         /   BULLETACTIVATE 3
         */
        if (enemyBulletActivate3 == 1)
        {
            if (enemies3[markerarIndex3].z == 0)
            {
                enemyBulletActivate3 = 0;
                markerarStop3 = 1;
            }
            if(markerarStop3 == 0)
            {
                enemyBullet3.x = enemies3[markerarIndex3].x;
                enemyBullet3.y = enemies3[markerarIndex3].y;
            }
            markerarStop3 = 1;
        }
        
        if (enemyBullet3.y != 32)
        {
            enemyBullet3.y += 1;
        }else
        {
            enemyBulletActivate3 = 0;
            markerarStop3 = 0;
        }
        
        
        
        /*
         /   TRÄFFSYSTEM för fiendeskott på spelare + hitbox
         */
        if (ship.y == enemyBullet1.y || ship.y == enemyBullet2.y || ship.y == enemyBullet3.y)
        {
            if (enemyBullet1.x == ship.x || enemyBullet1.x == (ship.x-1) || enemyBullet1.x == (ship.x+1) || enemyBullet2.x == ship.x || enemyBullet2.x == (ship.x-1) || enemyBullet2.x == (ship.x+1) || enemyBullet3.x == ship.x || enemyBullet3.x == (ship.x-1) || enemyBullet3.x == (ship.x+1))
            {
                HP -= 1;
                if (enemyBullet1.x == ship.x || enemyBullet1.x == (ship.x-1) || enemyBullet1.x == (ship.x+1))
                {
                    enemyBulletActivate1 = 0;
                    markerarStop1 = 0;
                    enemyBullet1.x = enemies1[markerarIndex1].x;
                    enemyBullet1.y = enemies1[markerarIndex1].y;
                }
                
                if (enemyBullet2.x == ship.x || enemyBullet2.x == (ship.x-1) || enemyBullet2.x == (ship.x+1))
                {
                    enemyBulletActivate2 = 0;
                    markerarStop2 = 0;
                    enemyBullet2.x = enemies2[markerarIndex2].x;
                    enemyBullet2.y = enemies2[markerarIndex2].y;
                }
                
                if (enemyBullet3.x == ship.x || enemyBullet3.x == (ship.x-1) || enemyBullet3.x == (ship.x+1))
                {
                    enemyBulletActivate3 = 0;
                    markerarStop3 = 0;
                    enemyBullet3.x = enemies3[markerarIndex3].x;
                    enemyBullet3.y = enemies3[markerarIndex3].y;
                }
            }
        }


        
        /*
         /   TRÄFFSYSTEM för spelarskott på fiende
         */
        if (bulletActivate == 1 && bullet.y != 0)
        {
            int k = 0;
            while(k!=10)
            {
                if (bullet.y == enemies1[k].y && enemies1[k].z != 0)
                {
                    if(bullet.x == (enemies1[k].x) || bullet.x == (enemies1[k].x+1) || bullet.x == (enemies1[k].x-1))
                    {
                        enemies1[k].z = 0;
                        enemiesHit++;
                        highscore++;
                        screen = 1;
                        k=9;
                    }
                }
                
                if (bullet.y == enemies2[k].y && enemies2[k].z != 0)
                {
                    if(bullet.x == (enemies2[k].x) || bullet.x == (enemies2[k].x+1) || bullet.x == (enemies2[k].x-1))
                    {
                        enemies2[k].z = 0;
                        enemiesHit++;
                        highscore++;
                        screen = 1;
                        k=9;
                    }
                }
                
                if (bullet.y == enemies3[k].y && enemies3[k].z != 0)
                {
                    if(bullet.x == (enemies3[k].x) || bullet.x == (enemies3[k].x+1) || bullet.x == (enemies3[k].x-1))
                    {
                        enemies3[k].z = 0;
                        enemiesHit++;
                        highscore++;
                        screen = 1;
                        k=9;
                    }
                }
                k++;
            }
            
            /*
             /   SKRIVARE
             */
            if (screen == 1)
            {
                draw3(ship, enemies1, enemies2, enemies3, enemyBullet1, enemyBullet2, enemyBullet3, markerarIndex1, markerarIndex2, markerarIndex3);
                screen = 0;
                bulletActivate = 0;
            }else
            {
                draw2(ship, bullet, enemies1, enemies2, enemies3, enemyBullet1, enemyBullet2, enemyBullet3, markerarIndex1, markerarIndex2, markerarIndex3);
                bullet.y -= 2;
            }
        }else
        {
            bulletActivate = 0;
            draw1(ship, enemies1, enemies2, enemies3, enemyBullet1, enemyBullet2, enemyBullet3, markerarIndex1, markerarIndex2, markerarIndex3);
        }
        
        
        if (counter == 50)
        {
            counter1++;
            
            if (counter1 % 2 == 0)
            {
                int i = 0;
                while (i!=10)
                {
                    enemies1[i].x += 4;
                    enemies2[i].x += 4;
                    enemies3[i].x += 4;
                    i++;
                }
                
            }else
            {
                int i = 0;
                while (i!=10)
                {
                    enemies1[i].x -= 4;
                    enemies2[i].x -= 4;
                    enemies3[i].x -= 4;
                    i++;
                }
            }
            counter = 0;
        }
        
        counter++;
        delay(20);
        
        
        /*
        /   HP-SYSTEM
        */
        if(HP == 8)
        {
            PORTE = 0x0FF;
        }
        if(HP == 7)
        {
            PORTE = 0x07F;
        }
        if(HP == 6)
        {
            PORTE = 0x03F;
        }
        if(HP == 5)
        {
            PORTE = 0x01F;
        }
        if(HP == 4)
        {
            PORTE = 0x00F;
        }
        if(HP == 3)
        {
            PORTE = 0x07;
        }
        if(HP == 2)
        {
            PORTE = 0x03;
        }
        if(HP == 1)
        {
            PORTE = 0x01;
        }
        
        
        
        if (enemiesHit == 30)
        {
            huvudkoden();
            delay(500);
        }

        
        if (HP == 0)
        {
            PORTE = 0x0;
            delay(600);
            
            int pos = 2;
            
            char score1[pos];
            int i = 0;
            while(i < pos)
            {
                score1[i] = (char)hsArr[i] + '0';
                i++;
            }
            
            while(1)
            {
                renderScreen(gameOver);
                int btn2 = getbtns();
                
                if(btn2 == 1)
                {
                    break;
                }
            }
            break;
        }
        
    }

}


void menu()
{
    HP = 8;
    highscore = 0;
    
    while(1)
    {
        int btn = getbtns();
        renderScreen(menu1);
        
        if(btn == 1)
        {
            delay(100);
            break;
        }
        
        if(btn == 4)
        {
            huvudkoden();
        }
    }
    
    while(1)
    {
        int btn = getbtns();
        renderScreen(menu2);
        
        if(btn == 1)
        {
            delay(100);
            break;
        }
        
        if(btn == 4)
        {
            huvudkoden();
        }
    }
    
    while(1)
    {
        int btn = getbtns();
        renderScreen(menu3);
        
        if(btn == 1)
        {
            delay(100);
            menu();
        }
        
        if(btn == 4)
        {
            clearGame();
            display_update();
            delay(200);
            while(1)
            {
                display_string(0, score1);
                /*display_string(1, hsArr[3]);
                display_string(2, hsArr[2]);
                display_string(3, hsArr[1]);*/

                int btns = getbtns();
                if (btns == 4)
                {
                    delay(200);
                    menu();
                }
            }
        }
    }
}

#ifndef initStartScreen_h
#define initStartScreen_h

#include <stdio.h>

#endif


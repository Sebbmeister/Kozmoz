#ifndef funktioner_h
#define funktioner_h

#include <stdio.h>

#endif

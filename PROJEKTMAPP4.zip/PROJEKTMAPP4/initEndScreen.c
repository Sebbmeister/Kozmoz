#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <pic32mx.h>
#include "main.h"
#include "initGame.h"
#include "objekt.h"
#include "assets.h"
#include "funktioner.h"


/*void endScreene(void)
{
    int stop1 = 0;
    while(1)
    {
        renderScreen(gameOver);
        int btn = getbtns();
        
        if(btn == 1)
        {
            stop1 = 1;
            delay(300);
        }
        
        if (stop1 == 1)break;
    }
}*/

#include <stdint.h>
#include <pic32mx.h>
#include "project.h"
#include "funktioner.h"


/*int getsw(void)
{
  int switchStatus = (PORTD >> 8) & 0x000F;

  return switchStatus;
}*/

int getbtns(void)
{
    int buttonStatus = (PORTD >> 0x5) & 0x000F;

    return buttonStatus;
}

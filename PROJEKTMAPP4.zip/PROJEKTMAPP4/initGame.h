#ifndef initGame_h
#define initGame_h

#include <stdio.h>


#endif



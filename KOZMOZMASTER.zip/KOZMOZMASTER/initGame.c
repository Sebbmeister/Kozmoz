#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <pic32mx.h>
#include "main.h"
#include "initGame.h"
#include "objekt.h"


void initGame(void)
{
    int i = 0;
    int bredd = 24;
    while(i!=10)
    {
        enemies1[i].x = bredd;   //x koordinat
        enemies1[i].y = 1;   //y koordinat
        enemies1[i].z = 1;   //0 = alive, 1 = dead
        
        enemies2[i].x = bredd;   //x koordinat
        enemies2[i].y = 5;   //y koordinat
        enemies2[i].z = 1;   //0 = alive, 1 = dead
        
        enemies3[i].x = bredd;   //x koordinat
        enemies3[i].y = 9;   //y koordinat
        enemies3[i].z = 1;   //0 = alive, 1 = dead
        
        bredd += 8;
        i++;
    }
    
        // reset
        AD1CON1 = 0x0000;
        AD1CON2 = 0x0000;
        AD1CON3 = 0x0000;
        
        // ASAM: ADC Sample Auto-Start bit
        AD1CON1SET = 0x4;
        // SSRC: auto convert
        AD1CON1SET = 0xE0;
        // FORM: uint32, 0 - 1024
        AD1CON1SET = 0x400;
        
        // BUFM: Result buffer mode, split in 2
        AD1CON2SET = 0x2;
        // SMPI: 2 sample/convert sequences between interrupts
        AD1CON2SET = 0x4;
        // CSCNA: Scan inputs
        AD1CON2SET = 0x400;
        
        // SAMC: 31 TAD
        AD1CON3SET = 0xF00;
        
        // CSSL: ADC Input Pin Scan Selection bits
        AD1CSSLSET = 0x0110;
        
        // start
        AD1CON1SET = 0x8000;
    
}



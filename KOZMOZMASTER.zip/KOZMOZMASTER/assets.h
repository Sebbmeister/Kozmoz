#ifndef assets_h
#define assets_h

#include <stdio.h>

extern const uint8_t const font[];
extern const uint8_t const start[];
extern const uint8_t const menu1[];
extern const uint8_t const menu2[];
extern const uint8_t const menu3[];
extern const uint8_t const gameOver[];



#endif

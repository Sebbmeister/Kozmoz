#include <stdint.h>
#include <stdio.h>
#include <pic32mx.h>
#include "project.h"
#include "display.h"
#include "assets.h"
#include "main.h"
#include "objekt.h"
#include "funktioner.h"
#include "define.h"
#include "initGame.h"


int main(void)
{

        initGame();
        spiinit();
        display_init();
        display_update();
        startingScreen();
    
        initGame();
        TRISE = TRISE & 0xFF00;
        TRISD = TRISD & 0x00F0;
    
    
    while (1)
    {
        spiinit();
        display_init();
        display_update();
        menu();
        delay(100);
    }
}



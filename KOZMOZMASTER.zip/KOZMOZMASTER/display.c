#include <stdint.h>   /* Declarations of uint_32 and the like */
#include <pic32mx.h>  /* Declarations of system-specific addresses etc */
#include "display.h"
#include "project.h"
#include "assets.h"
#include "main.h"
#include "objekt.h"
#include "define.h"
#include <stdlib.h>

int duration;
int randomNum;
int shot = 0;

/* Declare a helper function which is local to this file */
static void num32asc( char * s, int );

uint8_t game[128*4] = {0};
int enemyTraff = 0;
int enemyStart = 24;

void spiinit(void)
{
    SYSKEY = 0xAA996655;  /* Unlock OSCCON, step 1 */
    SYSKEY = 0x556699AA;  /* Unlock OSCCON, step 2 */
    while(OSCCON & (1 << 21)); /* Wait until PBDIV ready */
    OSCCONCLR = 0x180000; /* clear PBDIV bit <0,1> */
    while(OSCCON & (1 << 21));  /* Wait until PBDIV ready */
    SYSKEY = 0x0;  /* Lock OSCCON */
    
    /* Set up output pins */
    AD1PCFG = 0xFFFF;
    ODCE = 0x0;
    TRISECLR = 0xFF;
    PORTE = 0x0;
    
    /* Output pins for display signals */
    PORTF = 0xFFFF;
    PORTG = (1 << 9);
    ODCF = 0x0;
    ODCG = 0x0;
    TRISFCLR = 0x70;
    TRISGCLR = 0x200;
    
    /* Set up input pins */
    TRISDSET = (1 << 8);
    TRISFSET = (1 << 1);
    
    /* Set up SPI2 as master */
    SPI2CON = 0;
    SPI2BRG = 4;
    /* SPI2STAT bit SPIROV = 0; */
    SPI2STATCLR = 0x40;
    /* SPI2CON bit CKP = 1; */
    SPI2CONSET = 0x40;
    /* SPI2CON bit MSTEN = 1; */
    SPI2CONSET = 0x20;
    /* SPI2CON bit ON = 1; */
    SPI2CONSET = 0x8000;
    
    /* Set up SPI1 as slave */
    SPI1CON = 0;
    SPI1BRG = 4;
    /* SPI2STAT bit SPIROV = 0; */
    SPI1STATCLR = 0x40;
    /* SPI2CON bit CKP = 1; */
    SPI1CONSET = 0x40;
    /* SPI2CON bit ON = 1; */
    SPI1CONSET = 0x8000;
    
}


/* quicksleep:
   A simple function to create a small delay.
   Very inefficient use of computing resources,
   but very handy in some special cases. */
void quicksleep(int cyc)
{
	int i;
	for(i = cyc; i > 0; i--);
}



/* display_debug
   A function to help debugging.

   After calling display_debug,
   the two middle lines of the display show
   an address and its current contents.

   There's one parameter: the address to read and display.

   Note: When you use this function, you should comment out any
   repeated calls to display_image; display_image overwrites
   about half of the digits shown by display_debug.
*/


void display_debug( volatile int * const addr )
{
  display_string( 1, "Addr" );
  display_string( 2, "Data" );
  num32asc( &textbuffer[1][6], (int) addr );
  num32asc( &textbuffer[2][6], *addr );
  display_update();
}



uint8_t spi_send_recv(uint8_t data)
{
	while(!(SPI2STAT & 0x08));
	SPI2BUF = data;
	while(!(SPI2STAT & 1));
	return SPI2BUF;
}



void display_init(void)
{
    DISPLAY_CHANGE_TO_COMMAND_MODE;
	quicksleep(10);
	DISPLAY_ACTIVATE_VDD;
	quicksleep(1000000);
	
	spi_send_recv(0xAE);
	DISPLAY_ACTIVATE_RESET;
	quicksleep(10);
	DISPLAY_DO_NOT_RESET;
	quicksleep(10);
	
	spi_send_recv(0x8D);
	spi_send_recv(0x14);
	
	spi_send_recv(0xD9);
	spi_send_recv(0xF1);
	
	DISPLAY_ACTIVATE_VBAT;
	quicksleep(10000000);
	
	spi_send_recv(0xA1);
	spi_send_recv(0xC8);
	
	spi_send_recv(0xDA);
	spi_send_recv(0x20);
	
	spi_send_recv(0xAF);
}



void display_string(int line, char *s)
{
	int i;
	if(line < 0 || line >= 4)
		return;
	if(!s)
		return;
	
	for(i = 0; i < 16; i++)
		if(*s) {
			textbuffer[line][i] = *s;
			s++;
		} else
			textbuffer[line][i] = ' ';
}



void display_image(int x, const uint8_t *data)
{
	int i, j;
	
	for(i = 0; i < 4; i++) {
		DISPLAY_CHANGE_TO_COMMAND_MODE;

		spi_send_recv(0x22);
		spi_send_recv(i);
		
		spi_send_recv(x & 0xF);
		spi_send_recv(0x10 | ((x >> 4) & 0xF));
		
		DISPLAY_CHANGE_TO_DATA_MODE;
		
		for(j = 0; j < 32; j++)
			spi_send_recv(~data[i*32 + j]);
	}
}



void display_update(void)
{
	int i, j, k;
	int c;
	for(i = 0; i < 4; i++) {
		DISPLAY_CHANGE_TO_COMMAND_MODE;
		spi_send_recv(0x22);
		spi_send_recv(i);
		
		spi_send_recv(0x0);
		spi_send_recv(0x10);
		
		DISPLAY_CHANGE_TO_DATA_MODE;
		
		for(j = 0; j < 16; j++) {
			c = textbuffer[i][j];
			if(c & 0x80)
				continue;
			
			for(k = 0; k < 8; k++)
				spi_send_recv(font[c*8 + k]);
		}
	}
}





/* Helper function, local to this file.
   Converts a number to hexadecimal ASCII digits. */
static void num32asc( char * s, int n ) 
{
  int i;
  for( i = 28; i >= 0; i -= 4 )
    *s++ = "0123456789ABCDEF"[ (n >> i) & 15 ];
}

void renderScreen(uint8_t arr[])
{
    int i, j;
    
    for(i = 0; i < 4; i++)
    {
        DISPLAY_COMMAND_DATA_PORT &= ~DISPLAY_COMMAND_DATA_MASK;
        spi_send_recv(0x22);
        spi_send_recv(i);
        
        spi_send_recv(0 & 0xF);
        spi_send_recv(0x10 | ((0 >> 4) & 0xF));
        
        DISPLAY_COMMAND_DATA_PORT |= DISPLAY_COMMAND_DATA_MASK;
        
        for(j = 0; j < 128; j++)
            spi_send_recv(arr[i*128 + j]);
    }
}



void pixelGlow(int x, int y)
{
    short offset = 0;
    if (y > 0) { offset = y / 8; }
    game[offset * 128 + x] |= 1 << (y - offset * 8);
}

void drawShip2(Ship f)
{
    pixelGlow((f.x), (f.y));
    
    pixelGlow((f.x+1), (f.y+1));
    pixelGlow((f.x-1), (f.y+1));
    
    pixelGlow((f.x+1), (f.y+2));
    pixelGlow((f.x-1), (f.y+2));
    pixelGlow((f.x+2), (f.y+2));
    pixelGlow((f.x-2), (f.y+2));
    
    pixelGlow((f.x), (f.y+3));
    pixelGlow((f.x+2), (f.y+3));
    pixelGlow((f.x-2), (f.y+3));
    
    pixelGlow((f.x-2), (f.y+4));
    pixelGlow((f.x-1), (f.y+4));
    pixelGlow((f.x), (f.y+4));
    pixelGlow((f.x+1), (f.y+4));
    pixelGlow((f.x+2), (f.y+4));
    
}


void drawShip(Ship b)
{
    pixelGlow((b.x), (b.y));
    pixelGlow((b.x), (b.y+1));
    
    pixelGlow((b.x), (b.y+2));
    pixelGlow((b.x+1), (b.y+2));
    pixelGlow((b.x-1), (b.y+2));
    
    pixelGlow((b.x), (b.y+3));
    pixelGlow((b.x+1), (b.y+3));
    pixelGlow((b.x+2), (b.y+3));
    pixelGlow((b.x-1), (b.y+3));
    pixelGlow((b.x-2), (b.y+3));
    
    pixelGlow((b.x), (b.y+4));
    pixelGlow((b.x+1), (b.y+4));
    pixelGlow((b.x+2), (b.y+4));
    pixelGlow((b.x-1), (b.y+4));
    pixelGlow((b.x-2), (b.y+4));
}

void drawEnemies(Enemy e1[], Enemy e2[], Enemy e3[])
{
    int i = 0;
    while (i!=10)
    {
        if (e1[i].z == 1)    //still alive
        {
            pixelGlow((e1[i].x), e1[i].y);
            
            pixelGlow((e1[i].x-1), e1[i].y+1);
            pixelGlow((e1[i].x+1), e1[i].y+1);
            
            pixelGlow((e1[i].x-1), e1[i].y-1);
            pixelGlow((e1[i].x+1), e1[i].y-1);
            
            pixelGlow((e1[i].x), e1[i].y-1);
        }
        
        if (e2[i].z == 1)    //still alive
        {
            
            
            pixelGlow((e2[i].x), e2[i].y+1);
            pixelGlow((e2[i].x+1), e2[i].y);
            
            pixelGlow((e2[i].x-1), e2[i].y);
            pixelGlow((e2[i].x), e2[i].y-1);
            
        
        }
        
        if (e3[i].z == 1)    //still alive
        {
            pixelGlow((e3[i].x+1), e3[i].y+1);
            
            pixelGlow((e3[i].x), e3[i].y+1);
            pixelGlow((e3[i].x+1), e3[i].y);
            
            pixelGlow((e3[i].x-1), e3[i].y);
            pixelGlow((e3[i].x), e3[i].y-1);
            
            pixelGlow((e3[i].x-1), e3[i].y+1);
        }
        i++;
    }
    duration++;
}


void drawEnemyBullet1(Bullet eb1, Enemy e1[], int markerarIndex1, int eba1)
{
    if(e1[markerarIndex1].z == 1 && eba1 == 1)
    {
        pixelGlow(eb1.x, eb1.y);
    }
}

void drawEnemyBullet2(Bullet eb2, Enemy e2[], int markerarIndex2, int eba2)
{
    if(e2[markerarIndex2].z == 1 && eba2 == 1)
    {
        pixelGlow(eb2.x, eb2.y);
    }
}

void drawEnemyBullet3(Bullet eb3, Enemy e3[], int markerarIndex3, int eba3)
{
    if(e3[markerarIndex3].z == 1 && eba3 == 1)
    {
        pixelGlow(eb3.x, eb3.y);
    }
}

void drawBullet2(Bullet g)
{
    pixelGlow(g.x, g.y);
    pixelGlow(g.x, g.y-1);
}

void drawBullet(Bullet a)
{
    pixelGlow(a.x, a.y);
    pixelGlow(a.x, a.y-1);
}


void clearGame()
{
    int i;
    for (i = 0; i < sizeof(game); i++) { game[i] = 0; }
}



void draw6(Ship ship, Bullet bullet, Enemy enemies1[], Enemy enemies2[], Enemy enemies3[], Bullet enemyBullet1, Bullet enemyBullet2, Bullet enemyBullet3, int markerarIndex1, int markerarIndex2, int markerarIndex3, int enemyBulletActivate1, int enemyBulletActivate2, int enemyBulletActivate3)
{
    clearGame();
    
    drawShip(ship);
    drawEnemies(enemies1, enemies2, enemies3);
    drawBullet(bullet);
    
    drawEnemyBullet3(enemyBullet3, enemies3, markerarIndex3, enemyBulletActivate3);
    drawEnemyBullet2(enemyBullet2, enemies2, markerarIndex2, enemyBulletActivate2);
    drawEnemyBullet1(enemyBullet1, enemies1, markerarIndex1, enemyBulletActivate1);
    
    renderScreen(game);
}



void draw5(Ship ship, Enemy enemies1[], Enemy enemies2[], Enemy enemies3[], Bullet enemyBullet1, Bullet enemyBullet2, Bullet enemyBullet3, int markerarIndex1, int markerarIndex2, int markerarIndex3, int enemyBulletActivate1, int enemyBulletActivate2, int enemyBulletActivate3)
{
    clearGame();
    
    drawShip(ship);
    drawEnemies(enemies1, enemies2, enemies3);
    
    drawEnemyBullet3(enemyBullet3, enemies3, markerarIndex3, enemyBulletActivate3);
    drawEnemyBullet2(enemyBullet2, enemies2, markerarIndex2, enemyBulletActivate2);
    drawEnemyBullet1(enemyBullet1, enemies1, markerarIndex1, enemyBulletActivate1);
    
    renderScreen(game);
}



void draw4(Ship ship, Ship ship2, Bullet bullet, Bullet bullet2, Enemy enemies1[], Enemy enemies2[], Enemy enemies3[], Bullet enemyBullet1, Bullet enemyBullet2, Bullet enemyBullet3, int markerarIndex1, int markerarIndex2, int markerarIndex3, int enemyBulletActivate1, int enemyBulletActivate2, int enemyBulletActivate3)
{
    clearGame();
    
    drawShip(ship);
    drawShip2(ship2);
    drawEnemies(enemies1, enemies2, enemies3);
    drawBullet(bullet);
    drawBullet2(bullet2);
    
    drawEnemyBullet3(enemyBullet3, enemies3, markerarIndex3, enemyBulletActivate3);
    drawEnemyBullet2(enemyBullet2, enemies2, markerarIndex2, enemyBulletActivate2);
    drawEnemyBullet1(enemyBullet1, enemies1, markerarIndex1, enemyBulletActivate1);
    
    renderScreen(game);
}


void draw3(Ship ship, Ship ship2, Bullet bullet2, Enemy enemies1[], Enemy enemies2[], Enemy enemies3[], Bullet enemyBullet1, Bullet enemyBullet2, Bullet enemyBullet3, int markerarIndex1, int markerarIndex2, int markerarIndex3, int enemyBulletActivate1, int enemyBulletActivate2, int enemyBulletActivate3)
{
    clearGame();
    
    drawShip(ship);
    drawShip2(ship2);
    drawEnemies(enemies1, enemies2, enemies3);
    drawBullet2(bullet2);
    
    drawEnemyBullet3(enemyBullet3, enemies3, markerarIndex3, enemyBulletActivate3);
    drawEnemyBullet2(enemyBullet2, enemies2, markerarIndex2, enemyBulletActivate2);
    drawEnemyBullet1(enemyBullet1, enemies1, markerarIndex1, enemyBulletActivate1);
    
    renderScreen(game);
}


void draw2(Ship ship, Ship ship2, Bullet bullet, Enemy enemies1[], Enemy enemies2[], Enemy enemies3[], Bullet enemyBullet1, Bullet enemyBullet2, Bullet enemyBullet3, int markerarIndex1, int markerarIndex2, int markerarIndex3, int enemyBulletActivate1, int enemyBulletActivate2, int enemyBulletActivate3)
{
    clearGame();
    
    drawShip(ship);
    drawShip2(ship2);
    drawEnemies(enemies1, enemies2, enemies3);
    drawBullet(bullet);
    
    drawEnemyBullet3(enemyBullet3, enemies3, markerarIndex3, enemyBulletActivate3);
    drawEnemyBullet2(enemyBullet2, enemies2, markerarIndex2, enemyBulletActivate2);
    drawEnemyBullet1(enemyBullet1, enemies1, markerarIndex1, enemyBulletActivate1);
    
    renderScreen(game);
}


void draw1(Ship ship, Ship ship2, Enemy enemies1[], Enemy enemies2[], Enemy enemies3[], Bullet enemyBullet1, Bullet enemyBullet2, Bullet enemyBullet3, int markerarIndex1, int markerarIndex2, int markerarIndex3, int enemyBulletActivate1, int enemyBulletActivate2, int enemyBulletActivate3)
{
    clearGame();
    
    drawShip(ship);
    drawShip2(ship2);
    drawEnemies(enemies1, enemies2, enemies3);
    
    drawEnemyBullet3(enemyBullet3, enemies3, markerarIndex3, enemyBulletActivate3);
    drawEnemyBullet2(enemyBullet2, enemies2, markerarIndex2, enemyBulletActivate2);
    drawEnemyBullet1(enemyBullet1, enemies1, markerarIndex1, enemyBulletActivate1);
    
    renderScreen(game);
}


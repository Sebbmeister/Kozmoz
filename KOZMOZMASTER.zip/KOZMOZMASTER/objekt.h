#ifndef objekt_h
#define objekt_h

#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>

typedef struct{
    short x, y;
}Ship;

Ship ship;
Ship ship2;


typedef struct{
    short x, y;
}Bullet;

Bullet bullet;
Bullet bullet2;

Bullet enemyBullet1;
Bullet enemyBullet2;
Bullet enemyBullet3;


typedef struct{
    short x, y, z;
}Enemy;

Enemy enemies1[10];
Enemy enemies2[10];
Enemy enemies3[10];



#endif

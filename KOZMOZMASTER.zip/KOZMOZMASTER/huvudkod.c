#include <stdint.h>
#include <stdio.h>
#include <pic32mx.h>
#include "project.h"
#include "display.h"
#include "assets.h"
#include "main.h"
#include "objekt.h"
#include "funktioner.h"
#include "define.h"
#include "initGame.h"


int HP;
int hsArr[2] = {0,0};
int highscore = 0;
int z;

int ADCValueP1, ADCValueP2;

char score1[2] = {'0', '0'};
char score2[2] = {'0', '0'};
char score3[2] = {'0', '0'};


void startingScreen()
{
    
    while(1)
    {
        renderScreen(start);
        int btn3 = getbtns();
        
        if(btn3 == 1 || btn3 == 2 || btn3 == 4)
        {
            break;
        }
        
    }
}

void user_isr()
{
    
}

void delay(int k)
{
    int j = 0;
    while (k > 0){
        for (j = 0; j < 7500; j++){
        }
        k--;
    }
}


void onePlayer()
{

    int markerarStop1 = 0;
    int markerarStop2 = 0;
    int markerarStop3 = 0;
    
    int ADCValueP1, ADCValueP2;

    
    int timecounter1 = 0;
    int timecounter2 = 0;
    int timecounter3 = 0;
    
    int timematch1 = 0;
    int timematch2 = 0;
    
    int markerarIndex1 = 2;
    int markerarIndex2 = 5;
    int markerarIndex3 = 7;
    
    int counter = 0;
    int counter1 = 0;
    
    int bulletActivate = 0;
    int bulletActivate2 = 0;
    int enemyBulletActivate1 = 0;
    int enemyBulletActivate2 = 0;
    int enemyBulletActivate3 = 0;
    int MAX_X = 128;
    int MAX_Y = 32;
    int enemiesHit = 0;
    
    int stop1 = 0;
    int stop2 = 0;
    int stop3 = 0;
    int stop4 = 0;
    
    /*
    /   Revive Enemies
    */
    z = 0;
    while(z!=10)
    {
        enemies1[z].z = 1;
        enemies2[z].z = 1;
        enemies3[z].z = 1;
        z++;
    }
    
    ship.x = 32;
    ship.y = 27;

    T2CONSET = 0x70;    //Prescaler 256
    PR2 = 0x0110;       //Set period register (Beräknat)
    TMR2 = 0;           //Reset clock (clear)
    T2CONSET = 0x8000;  //Starts clock, bit 15(on) set to 1
    
    T4CONSET = 0x60;    //Prescaler 64
    PR4 = 0x0130;      //Set period register (Beräknat)
    TMR4 = 0;           //Reset clock (clear)
    T4CONSET = 0x8000;  //Starts clock, bit 15(on) set to 1
    
    
    
    while(1)
    {
        
        /*                      /
        /                       /
        /       JOYSTICKS       /
        /                       /
        */                      //
        
        
        //startar sampling och kör tills buffer är "fylld"
        IFSCLR(1) = 0x0002;
        AD1CON1SET = 0x0004;
        while (!IFS(1) & 0x0002);
        
        ADCValueP1 = 512;
        ADCValueP2 = 512;
        
        //Läser av från buffer och lägger värde "0-1024" på variabler
        if (AD1CON2 & 0x0080)
        {
            ADCValueP1 = ADC1BUF0;
            ADCValueP2 = ADC1BUF1;
            
        }else
        {
            ADCValueP1 = ADC1BUF8;
            ADCValueP2 = ADC1BUF9;
        }
        
        
        /*
         /   Spelare 1 joystick
         */
        if(ADCValueP1 > 800)
        {
            if (ship.x != (MAX_X - 10))
            {
                ship.x += 1;
            }
        }
        
        if (ADCValueP1 < 200)
        {
            if (ship.x != 10)
            {
                ship.x -= 1;
            }
        }
        
        
        

        
        
        /*                              /
        /                               /
        /       KLOCKSYSTEM / RNG       /
        /                               /
        */                              //
        
        if (IFS(0) & 0x100)
        {
            timecounter1++;
            IFSCLR(0) = 0x100;
        }
        
        if (IFS(0) & 0x10000)
        {
            timecounter2++;
            IFSCLR(0) = 0x10000;
        }
        
        if (timecounter1 == 10)
        {
            timecounter1 = 0;
        }
        if (timecounter2 == 10)
        {
            timecounter2 = 0;
        }
        
       
        
        
        
        /*
         /   "KLOCKA FÖR FIENDERAD 1"
         */
        if (timecounter2 == timecounter1 && enemyBulletActivate1 == 0)
        {
            markerarIndex1 = timecounter1;
            enemyBulletActivate1 = 1;
            markerarStop1 = 0;
        }
        
        
        
        /*
         /   "KLOCKA FÖR FIENDERAD 2"
         */
        if(timecounter2 != timecounter1 && enemyBulletActivate2 == 0)
        {
            markerarIndex2 = timecounter2;
            enemyBulletActivate2 = 1;
            markerarStop2 = 0;
        }
        
        
        /*
         /   "KLOCKA FÖR FIENDERAD 3"
         */
        if(timecounter2 == timecounter1 && timecounter1 %2 == 0 && enemyBulletActivate3 == 0)
        {
            markerarIndex3 = ((timecounter1 + timecounter2)/2);
            enemyBulletActivate3 = 1;
            markerarStop3 = 0;
        }
        
        

        
        
        /*
        /   SKOTTAKTIVERING FÖR SPELARE 1
        */
        int btn = getbtns();
        
        //Button 4
        if(btn == 4)
        {
            if (bulletActivate !=1)
            {
                bullet.x = ship.x;
                bullet.y = ship.y;
                bulletActivate = 1;
            }
        }
        
        
        
        
        /*                                  /
        /                                   /
        /       SKOTTHANTERING FIENDER      /
        /                                   /
        */                                  //
        
        
        
        
        /*
         /   BULLETACTIVATE 1
         */
        if (enemyBulletActivate1 == 1)
        {
            if (enemies1[markerarIndex1].z == 0)
            {
                enemyBulletActivate1 = 0;
                markerarStop1 = 1;
            }
            if(markerarStop1 == 0)
            {
                enemyBullet1.x = enemies1[markerarIndex1].x;
                enemyBullet1.y = enemies1[markerarIndex1].y;
            }
            markerarStop1 = 1;
        }
        
        if (enemyBullet1.y < 32 && enemyBulletActivate1 == 1)
        {
            
            if (enemiesHit >= 15)
            {
                enemyBullet1.y += 2;
            }else
            {
                enemyBullet1.y += 1;
            }
            
        }else
        {
            enemyBulletActivate1 = 0;
            markerarStop1 = 0;
        }
        
        
        /*
         /   BULLETACTIVATE 2
         */
        if (enemyBulletActivate2 == 1)
        {
            if (enemies2[markerarIndex2].z == 0)
            {
                enemyBulletActivate2 = 0;
                markerarStop1 = 2;
            }
            if(markerarStop2 == 0)
            {
                enemyBullet2.x = enemies2[markerarIndex2].x;
                enemyBullet2.y = enemies2[markerarIndex2].y;
            }
            markerarStop2 = 1;
        }
        
        if (enemyBullet2.y < 32 && enemyBulletActivate2 == 1)
        {
            if (enemiesHit >= 15)
            {
                enemyBullet2.y += 2;
            }else
            {
                enemyBullet2.y += 1;
            }
            
        }else
        {
            enemyBulletActivate2 = 0;
            markerarStop2 = 0;
        }
        
        
        /*
         /   BULLETACTIVATE 3
         */
        if (enemyBulletActivate3 == 1)
        {
            if (enemies3[markerarIndex3].z == 0)
            {
                enemyBulletActivate3 = 0;
                markerarStop3 = 1;
            }
            if(markerarStop3 == 0)
            {
                enemyBullet3.x = enemies3[markerarIndex3].x;
                enemyBullet3.y = enemies3[markerarIndex3].y;
            }
            markerarStop3 = 1;
        }
        
        if (enemyBullet3.y < 32 && enemyBulletActivate3 == 1)
        {
            if (enemiesHit >= 15)
            {
                enemyBullet3.y += 2;
            }else
            {
                enemyBullet3.y += 1;
            }
        }else
        {
            enemyBulletActivate3 = 0;
            markerarStop3 = 0;
        }
        
        
        
        
        
        
        
        /*                                                  /
        /                                                   /
        /       TRÄFFSYSTEM för fiendeskott på spelare1      /
        /                                                   /
        */
        
        
        /*
        /   Fiendeskott 1
        */
        if (enemyBullet1.y == ship.y || enemyBullet1.y == ship.y+1 || enemyBullet1.y == ship.y+2 || enemyBullet1.y == ship.y+3)
        {
            if (enemyBullet1.x == ship.x || enemyBullet1.x == (ship.x-1) || enemyBullet1.x == (ship.x+1) || enemyBullet1.x == (ship.x-2) || enemyBullet1.x == (ship.x+2))
            {
                HP -= 1;
                enemyBulletActivate1 = 0;
                markerarStop1 = 0;
                enemyBullet1.x = enemies1[markerarIndex1].x;
                enemyBullet1.y = enemies1[markerarIndex1].y;
            }
        }
        
        /*
         /   Fiendeskott 2
         */
        if (enemyBullet2.y == ship.y || enemyBullet2.y == ship.y+1 || enemyBullet2.y == ship.y+2 || enemyBullet2.y == ship.y+3)
        {
            if(enemyBullet2.x == ship.x || enemyBullet2.x == (ship.x-1) || enemyBullet2.x == (ship.x+1) || enemyBullet2.x == (ship.x-2) || enemyBullet2.x == (ship.x+2))
            {
                HP -= 1;
                enemyBulletActivate2 = 0;
                markerarStop2 = 0;
                enemyBullet2.x = enemies2[markerarIndex2].x;
                enemyBullet2.y = enemies2[markerarIndex2].y;
            }
        }
        
        /*
         /   Fiendeskott 3
         */
        if (enemyBullet3.y == ship.y || enemyBullet3.y == ship.y+1 || enemyBullet3.y == ship.y+2 || enemyBullet3.y == ship.y+3)
        {
            if(enemyBullet3.x == ship.x || enemyBullet3.x == (ship.x-1) || enemyBullet3.x == (ship.x+1) || enemyBullet3.x == (ship.x-2) || enemyBullet3.x == (ship.x+2))
            {
                HP -= 1;
                enemyBulletActivate3 = 0;
                markerarStop3 = 0;
                enemyBullet3.x = enemies3[markerarIndex3].x;
                enemyBullet3.y = enemies3[markerarIndex3].y;
            }
        }
        
        
        
        
        
        
        
        /*
         /   TRÄFFSYSTEM för spelare 1:s skott på fiende
         */
        
        if (bullet.y == -1)
        {
            bulletActivate = 0;
        }
        
        if (bulletActivate == 1)
        {
            int k = 0;
            while(k!=10)
            {
                if (bullet.y == enemies1[k].y && enemies1[k].z != 0)
                {
                    if(bullet.x == (enemies1[k].x) || bullet.x == (enemies1[k].x+1) || bullet.x == (enemies1[k].x-1))
                    {
                        enemies1[k].z = 0;
                        enemiesHit++;
                        
                        if(highscore == 9)
                        {
                            hsArr[1] += 1;
                            highscore = 0;
                        }else
                        {
                            highscore++;
                        }
                        
                        bulletActivate = 0;
                        k=9;
                    }
                }
                
                if (bullet.y == enemies2[k].y && enemies2[k].z != 0)
                {
                    if(bullet.x == (enemies2[k].x) || bullet.x == (enemies2[k].x+1) || bullet.x == (enemies2[k].x-1))
                    {
                        enemies2[k].z = 0;
                        enemiesHit++;
                        
                        if(highscore == 9)
                        {
                            hsArr[1] += 1;
                            highscore = 0;
                        }else
                        {
                            highscore++;
                        }
                        
                        bulletActivate = 0;
                        k=9;
                    }
                }
                
                if (bullet.y == enemies3[k].y && enemies3[k].z != 0)
                {
                    if(bullet.x == (enemies3[k].x) || bullet.x == (enemies3[k].x+1) || bullet.x == (enemies3[k].x-1))
                    {
                        enemies3[k].z = 0;
                        enemiesHit++;
                        
                        if(highscore == 9)
                        {
                            hsArr[1] += 1;
                            highscore = 0;
                        }else
                        {
                          highscore++;
                        }
                        
                        
                        bulletActivate = 0;
                        k=9;
                    }
                }
                k++;
            }
            
        }
            
        
            
            
        //LÄGE 1 (inga skott)
            if(bulletActivate == 0)
            {
               draw5(ship, enemies1, enemies2, enemies3, enemyBullet1, enemyBullet2, enemyBullet3, markerarIndex1, markerarIndex2, markerarIndex3, enemyBulletActivate1, enemyBulletActivate2, enemyBulletActivate3);
            }
            
        //Läge 2 (spleare 1 skott)
            if(bulletActivate == 1)
            {
                draw6(ship, bullet, enemies1, enemies2, enemies3, enemyBullet1, enemyBullet2, enemyBullet3, markerarIndex1, markerarIndex2, markerarIndex3, enemyBulletActivate1, enemyBulletActivate2, enemyBulletActivate3);
                
                bullet.y -= 2;
            }
        
        

    
        
        /*
        /   FÖRFLYTTNING AV FIENDER
        */
        if (counter == 50)
        {
            counter1++;
            
            if (counter1 % 2 == 0)
            {
                int i = 0;
                while (i!=10)
                {
                    enemies1[i].x += 4;
                    enemies2[i].x += 4;
                    enemies3[i].x += 4;
                    i++;
                }
                
            }else
            {
                int i = 0;
                while (i!=10)
                {
                    enemies1[i].x -= 4;
                    enemies2[i].x -= 4;
                    enemies3[i].x -= 4;
                    i++;
                }
            }
            counter = 0;
        }
        
        counter++;
        delay(20);
        
        
        /*
        /   HP-SYSTEM
        */
        if(HP == 8)
        {
            PORTE = 0x0FF;
        }
        if(HP == 7)
        {
            PORTE = 0x07F;
        }
        if(HP == 6)
        {
            PORTE = 0x03F;
        }
        if(HP == 5)
        {
            PORTE = 0x01F;
        }
        if(HP == 4)
        {
            PORTE = 0x00F;
        }
        if(HP == 3)
        {
            PORTE = 0x07;
        }
        if(HP == 2)
        {
            PORTE = 0x03;
        }
        if(HP == 1)
        {
            PORTE = 0x01;
        }
        
        
        
        if (enemiesHit == 30)
        {
            delay(50);
            onePlayer();
        }

        
        /*
        /   SPELETS SLUT
        */
        if (HP == 0)
        {
            PORTE = 0x0;
            delay(600);
            
            hsArr[0] = highscore;
            
            while(1)
            {
                
                if (highscore == 0)
                {
                    break;
                }
                
                
                
                /*                      /
                /                       /
                /   HIGH-SCORE SYSTEM   /
                /                       /
                /*                      /
                 

                
                /*
                /   Jämför Score med FÖRSTAplats
                */
                if (hsArr[1] > (score1[0] - '0'))
                {
                    
                    score3[0] = score2[0];
                    score3[1] = score2[1];
                    
                    score2[0] = score1[0];
                    score2[1] = score1[1];
                    
                    score1[0] = (hsArr[1] + '0');
                    score1[1] = (hsArr[0] + '0');
                    break;
                }
                
                if (hsArr[1] == (score1[0] - '0'))
                {
                    if (hsArr[0] > (score1[1] - '0'))
                    {
                        
                        score3[0] = score2[0];
                        score3[1] = score2[1];
                        
                        score2[0] = score1[0];
                        score2[1] = score1[1];
                        
                        score1[0] = (hsArr[1] + '0');
                        score1[1] = (hsArr[0] + '0');
                        break;
                    }
                }
                
                
                
                /*
                 /   Jämför Score med ANDRAplats
                 */
                if (hsArr[1] > (score2[0] - '0'))
                {
                    score3[0] = score2[0];
                    score3[1] = score2[1];
                    
                    score2[0] = (hsArr[1] + '0');
                    score2[1] = (hsArr[0] + '0');
                    break;
                }
                
                if (hsArr[1] == (score2[0] - '0'))
                {
                    if (hsArr[0] > (score2[1] - '0'))
                    {
                        score3[0] = score2[0];
                        score3[1] = score2[1];
                        
                        score2[0] = (hsArr[1] + '0');
                        score2[1] = (hsArr[0] + '0');
                        break;
                    }
                }
                
                
                
                /*
                 /   Jämför Score med TREDJEplats
                 */
                if (hsArr[1] > (score3[0] - '0'))
                {
                    score3[0] = (hsArr[1] + '0');
                    score3[1] = (hsArr[0] + '0');
                    break;
                }
                
                if (hsArr[1] == (score3[0] - '0'))
                {
                    if (hsArr[0] > (score3[1] - '0'))
                    {
                        score3[0] = (hsArr[1] + '0');
                        score3[1] = (hsArr[0] + '0');
                        break;
                    }
                }
                
            }
            
            while(1)
            {
                renderScreen(gameOver);
                int btn2 = getbtns();
                
                if(btn2 == 2)
                {
                    delay(500);
                    break;
                }
                HP = 8;
            }
            break;
        }
        
    }

}


void twoPlayer()
{
    
    int markerarStop1 = 0;
    int markerarStop2 = 0;
    int markerarStop3 = 0;
    
    int ADCValueP1, ADCValueP2;
    
    
    int timecounter1 = 0;
    int timecounter2 = 0;
    int timecounter3 = 0;
    
    int timematch1 = 0;
    int timematch2 = 0;
    
    int markerarIndex1 = 2;
    int markerarIndex2 = 5;
    int markerarIndex3 = 7;
    
    int counter = 0;
    int counter1 = 0;
    
    int screen = 0;
    int screen2 = 0;
    int bulletActivate = 0;
    int bulletActivate2 = 0;
    int enemyBulletActivate1 = 0;
    int enemyBulletActivate2 = 0;
    int enemyBulletActivate3 = 0;
    int MAX_X = 128;
    int MAX_Y = 32;
    int enemiesHit = 0;
    
    int stop1 = 0;
    int stop2 = 0;
    int stop3 = 0;
    int stop4 = 0;
    
    
    /*
     /   Revive Enemies
     */
    z = 0;
    while(z!=10)
    {
        enemies1[z].z = 1;
        enemies2[z].z = 1;
        enemies3[z].z = 1;
        z++;
    }
    
    ship.x = 32;
    ship.y = 27;
    
    ship2.x = 96;
    ship2.y = 27;
    
    
    T2CONSET = 0x70;    //Prescaler 256
    PR2 = 0x7A12;       //Set period register (Beräknat)
    TMR2 = 0;           //Reset clock (clear)
    T2CONSET = 0x8000;  //Starts clock, bit 15(on) set to 1
    
    T4CONSET = 0x60;    //Prescaler 64
    PR4 = 0x927C;      //Set period register (Beräknat)
    TMR4 = 0;           //Reset clock (clear)
    T4CONSET = 0x8000;  //Starts clock, bit 15(on) set to 1
    
    
    
    
    while(1)
    {
        
        /*                      /
         /                       /
         /       JOYSTICKS       /
         /                       /
         */                      //
        
        
        //startar sampling och kör tills buffer är "fylld"
        IFSCLR(1) = 0x0002;
        AD1CON1SET = 0x0004;
        while (!IFS(1) & 0x0002);
        
        //Läser av från buffer och lägger värde "0-1024" på variabler
        if (AD1CON2 & 0x0080)
        {
            ADCValueP1 = ADC1BUF0;
            ADCValueP2 = ADC1BUF1;
            
        }else
        {
            ADCValueP1 = ADC1BUF8;
            ADCValueP2 = ADC1BUF9;
        }
        
        
        
        /*
        /   Spelare 1 joystick
        */
        if(ADCValueP1 > 800)
        {
            if (ship.x != (MAX_X - 10))
            {
                ship.x += 1;
            }
        }
        
        if (ADCValueP1 < 200)
        {
            if (ship.x != 10)
            {
                ship.x -= 1;
            }
        }
        
        
        /*
         /   Spelare 2 joystick
         */
        if(ADCValueP2 > 800)
        {
            if (ship2.x != (MAX_X - 10))
            {
                ship2.x += 1;
            }
        }
        
        if (ADCValueP2 < 200)
        {
            if (ship2.x != 10)
            {
                ship2.x -= 1;
            }
        }
        
        
        
        
        
        
        /*                              /
         /                               /
         /       KLOCKSYSTEM / RNG       /
         /                               /
         */                              //
        
        if (IFS(0) & 0x100)
        {
            timecounter1++;
            IFSCLR(0) = 0x100;
        }
        
        if (IFS(0) & 0x10000)
        {
            timecounter2++;
            IFSCLR(0) = 0x10000;
        }
        
        if (timecounter1 == 10)
        {
            timecounter1 = 0;
        }
        if (timecounter2 == 10)
        {
            timecounter2 = 0;
        }
        
        
        
        /*
         /   "KLOCKA FÖR FIENDERAD 1"
         */
        if (timecounter2 == timecounter1 && enemyBulletActivate1 == 0)
        {
            markerarIndex1 = timecounter1;
            enemyBulletActivate1 = 1;
            markerarStop1 = 0;
        }
        
        
        
        /*
         /   "KLOCKA FÖR FIENDERAD 2"
         */
        if(timecounter2 != timecounter1 && enemyBulletActivate2 == 0)
        {
            markerarIndex2 = timecounter2;
            enemyBulletActivate2 = 1;
            markerarStop2 = 0;
        }
        
        
        /*
         /   "KLOCKA FÖR FIENDERAD 3"
         */
        if(timecounter2 == timecounter1 && timecounter1 %2 == 0 && enemyBulletActivate3 == 0)
        {
            markerarIndex3 = ((timecounter1 + timecounter2)/2);
            enemyBulletActivate3 = 1;
            markerarStop3 = 0;
        }
        

        
        
        
        
        
        /*
         /   SKOTTAKTIVERING FÖR SPELARE 1 OCH 2
         */
        int btn = getbtns();
        
        //Button 4
        if(btn == 4 || btn == 5)
        {
            if (bulletActivate !=1)
            {
                bullet.x = ship.x;
                bullet.y = ship.y;
                bulletActivate = 1;
            }
        }
        
        //Button 2
        if (btn == 1 || btn == 5)
        {
            if (bulletActivate2 !=1)
            {
                bullet2.x = ship2.x;
                bullet2.y = ship2.y;
                bulletActivate2 = 1;
            }
        }
        
        
        
        
        
        /*                                  /
         /                                   /
         /       SKOTTHANTERING FIENDER      /
         /                                   /
         */                                  //
        
        
        
        /*
         /   BULLETACTIVATE 1
         */
        if (enemyBulletActivate1 == 1)
        {
            if (enemies1[markerarIndex1].z == 0)
            {
                enemyBulletActivate1 = 0;
                markerarStop1 = 1;
            }
            if(markerarStop1 == 0)
            {
                enemyBullet1.x = enemies1[markerarIndex1].x;
                enemyBullet1.y = enemies1[markerarIndex1].y;
            }
            markerarStop1 = 1;
        }
        
        if (enemyBullet1.y < 32 && enemyBulletActivate1 == 1)
        {
            
            if (enemiesHit >= 15)
            {
                enemyBullet1.y += 2;
            }else
            {
                enemyBullet1.y += 1;
            }
            
        }else
        {
            enemyBulletActivate1 = 0;
            markerarStop1 = 0;
        }
        
        
        /*
         /   BULLETACTIVATE 2
         */
        if (enemyBulletActivate2 == 1)
        {
            if (enemies2[markerarIndex2].z == 0)
            {
                enemyBulletActivate2 = 0;
                markerarStop1 = 2;
            }
            if(markerarStop2 == 0)
            {
                enemyBullet2.x = enemies2[markerarIndex2].x;
                enemyBullet2.y = enemies2[markerarIndex2].y;
            }
            markerarStop2 = 1;
        }
        
        if (enemyBullet2.y < 32 && enemyBulletActivate2 == 1)
        {
            if (enemiesHit >= 15)
            {
                enemyBullet2.y += 2;
            }else
            {
                enemyBullet2.y += 1;
            }
            
        }else
        {
            enemyBulletActivate2 = 0;
            markerarStop2 = 0;
        }
        
        
        /*
         /   BULLETACTIVATE 3
         */
        if (enemyBulletActivate3 == 1)
        {
            if (enemies3[markerarIndex3].z == 0)
            {
                enemyBulletActivate3 = 0;
                markerarStop3 = 1;
            }
            if(markerarStop3 == 0)
            {
                enemyBullet3.x = enemies3[markerarIndex3].x;
                enemyBullet3.y = enemies3[markerarIndex3].y;
            }
            markerarStop3 = 1;
        }
        
        if (enemyBullet3.y < 32 && enemyBulletActivate3 == 1)
        {
            if (enemiesHit >= 15)
            {
                enemyBullet3.y += 2;
            }else
            {
                enemyBullet3.y += 1;
            }
        }else
        {
            enemyBulletActivate3 = 0;
            markerarStop3 = 0;
        }
        
        
        
        
        
        
        
        /*                                                  /
         /                                                   /
         /       TRÄFFSYSTEM för fiendeskott på spelare1      /
         /                                                   /
         */
        
        
        /*
         /   Fiendeskott 1
         */
        if (enemyBullet1.y == ship.y || enemyBullet1.y == ship.y+1 || enemyBullet1.y == ship.y+2 || enemyBullet1.y == ship.y+3)
        {
            if (enemyBullet1.x == ship.x || enemyBullet1.x == (ship.x-1) || enemyBullet1.x == (ship.x+1) || enemyBullet1.x == (ship.x-2) || enemyBullet1.x == (ship.x+2))
            {
                HP -= 1;
                enemyBulletActivate1 = 0;
                markerarStop1 = 0;
                enemyBullet1.x = enemies1[markerarIndex1].x;
                enemyBullet1.y = enemies1[markerarIndex1].y;
            }
        }
        
        /*
         /   Fiendeskott 2
         */
        if (enemyBullet2.y == ship.y || enemyBullet2.y == ship.y+1 || enemyBullet2.y == ship.y+2 || enemyBullet2.y == ship.y+3)
        {
            if(enemyBullet2.x == ship.x || enemyBullet2.x == (ship.x-1) || enemyBullet2.x == (ship.x+1) || enemyBullet2.x == (ship.x-2) || enemyBullet2.x == (ship.x+2))
            {
                HP -= 1;
                enemyBulletActivate2 = 0;
                markerarStop2 = 0;
                enemyBullet2.x = enemies2[markerarIndex2].x;
                enemyBullet2.y = enemies2[markerarIndex2].y;
            }
        }
        
        /*
         /   Fiendeskott 3
         */
        if (enemyBullet3.y == ship.y || enemyBullet3.y == ship.y+1 || enemyBullet3.y == ship.y+2 || enemyBullet3.y == ship.y+3)
        {
            if(enemyBullet3.x == ship.x || enemyBullet3.x == (ship.x-1) || enemyBullet3.x == (ship.x+1) || enemyBullet3.x == (ship.x-2) || enemyBullet3.x == (ship.x+2))
            {
                HP -= 1;
                enemyBulletActivate3 = 0;
                markerarStop3 = 0;
                enemyBullet3.x = enemies3[markerarIndex3].x;
                enemyBullet3.y = enemies3[markerarIndex3].y;
            }
        }
        
        
        
        
        /*                                                  /
         /                                                   /
         /       TRÄFFSYSTEM för fiendeskott på spelare2     /
         /                                                   /
         */
        
        
        /*
         /   Fiendeskott 1
         */
        if (enemyBullet1.y == ship2.y || enemyBullet1.y == ship2.y+1 || enemyBullet1.y == ship2.y+2 || enemyBullet1.y == ship2.y+3)
        {
            if (enemyBullet1.x == ship2.x || enemyBullet1.x == (ship2.x-1) || enemyBullet1.x == (ship2.x+1) || enemyBullet1.x == (ship2.x-2) || enemyBullet1.x == (ship2.x+2))
            {
                HP -= 1;
                enemyBulletActivate1 = 0;
                markerarStop1 = 0;
                enemyBullet1.x = enemies1[markerarIndex1].x;
                enemyBullet1.y = enemies1[markerarIndex1].y;
            }
        }
        
        /*
         /   Fiendeskott 2
         */
        if (enemyBullet2.y == ship2.y || enemyBullet2.y == ship2.y+1 || enemyBullet2.y == ship2.y+2 || enemyBullet2.y == ship2.y+3)
        {
            if(enemyBullet2.x == ship2.x || enemyBullet2.x == (ship2.x-1) || enemyBullet2.x == (ship2.x+1) || enemyBullet2.x == (ship2.x-2) || enemyBullet2.x == (ship2.x+2))
            {
                HP -= 1;
                enemyBulletActivate2 = 0;
                markerarStop2 = 0;
                enemyBullet2.x = enemies2[markerarIndex2].x;
                enemyBullet2.y = enemies2[markerarIndex2].y;
            }
        }
        
        /*
         /   Fiendeskott 3
         */
        if (enemyBullet3.y == ship2.y || enemyBullet3.y == ship2.y+1 || enemyBullet3.y == ship2.y+2 || enemyBullet3.y == ship2.y+3)
        {
            if(enemyBullet3.x == ship2.x || enemyBullet3.x == (ship2.x-1) || enemyBullet3.x == (ship2.x+1) || enemyBullet3.x == (ship2.x-2) || enemyBullet3.x == (ship2.x+2))
            {
                HP -= 1;
                enemyBulletActivate3 = 0;
                markerarStop3 = 0;
                enemyBullet3.x = enemies3[markerarIndex3].x;
                enemyBullet3.y = enemies3[markerarIndex3].y;
            }
        }
        
        
        
        
        
        
        /*                                  /
        /                                   /
        /       Spelarskott på fiender      /
        /                                   /
        */                                  //
        
        
        
        
        /*
         /   TRÄFFSYSTEM för spelare 1:s skott på fiende
         */
        
        if (bullet.y == -1)
        {
            bulletActivate = 0;
        }
        
        if (bulletActivate == 1)
        {
            int k = 0;
            while(k!=10)
            {
                if (bullet.y == enemies1[k].y && enemies1[k].z != 0)
                {
                    if(bullet.x == (enemies1[k].x) || bullet.x == (enemies1[k].x+1) || bullet.x == (enemies1[k].x-1))
                    {
                        enemies1[k].z = 0;
                        enemiesHit++;
                        
                        if(highscore == 9)
                        {
                            hsArr[1] += 1;
                            highscore = 0;
                        }else
                        {
                            highscore++;
                        }
                        
                        bulletActivate = 0;
                        k=9;
                    }
                }
                
                if (bullet.y == enemies2[k].y && enemies2[k].z != 0)
                {
                    if(bullet.x == (enemies2[k].x) || bullet.x == (enemies2[k].x+1) || bullet.x == (enemies2[k].x-1))
                    {
                        enemies2[k].z = 0;
                        enemiesHit++;
                        
                        if(highscore == 9)
                        {
                            hsArr[1] += 1;
                            highscore = 0;
                        }else
                        {
                            highscore++;
                        }
                        
                        bulletActivate = 0;
                        k=9;
                    }
                }
                
                if (bullet.y == enemies3[k].y && enemies3[k].z != 0)
                {
                    if(bullet.x == (enemies3[k].x) || bullet.x == (enemies3[k].x+1) || bullet.x == (enemies3[k].x-1))
                    {
                        enemies3[k].z = 0;
                        enemiesHit++;
                        
                        if(highscore == 9)
                        {
                            hsArr[1] += 1;
                            highscore = 0;
                        }else
                        {
                            highscore++;
                        }
                        
                        bulletActivate = 0;
                        k=9;
                    }
                }
                k++;
            }
            
        }
        
        
        /*
         /   TRÄFFSYSTEM för spelare 2:s skott på fiende
         */
        if (bullet2.y == -1)
        {
            bulletActivate2 = 0;
        }
        
        if (bulletActivate2 == 1)
        {
            int k = 0;
            while(k!=10)
            {
                if (bullet2.y == enemies1[k].y && enemies1[k].z != 0)
                {
                    if(bullet2.x == (enemies1[k].x) || bullet2.x == (enemies1[k].x+1) || bullet2.x == (enemies1[k].x-1))
                    {
                        enemies1[k].z = 0;
                        enemiesHit++;
                        
                        if(highscore == 9)
                        {
                            hsArr[1] += 1;
                            highscore = 0;
                        }else
                        {
                            highscore++;
                        }
                        
                        bulletActivate2 = 0;
                        k=9;
                    }
                }
                
                if (bullet2.y == enemies2[k].y && enemies2[k].z != 0)
                {
                    if(bullet2.x == (enemies2[k].x) || bullet2.x == (enemies2[k].x+1) || bullet2.x == (enemies2[k].x-1))
                    {
                        enemies2[k].z = 0;
                        enemiesHit++;
                        
                        if(highscore == 9)
                        {
                            hsArr[1] += 1;
                            highscore = 0;
                        }else
                        {
                            highscore++;
                        }
                        bulletActivate2 = 0;
                        k=9;
                    }
                }
                
                if (bullet2.y == enemies3[k].y && enemies3[k].z != 0)
                {
                    if(bullet2.x == (enemies3[k].x) || bullet2.x == (enemies3[k].x+1) || bullet2.x == (enemies3[k].x-1))
                    {
                        enemies3[k].z = 0;
                        enemiesHit++;
                        
                        if(highscore == 9)
                        {
                            hsArr[1] += 1;
                            highscore = 0;
                        }else
                        {
                            highscore++;
                        }
                        bulletActivate2 = 0;
                        k=9;
                    }
                }
                k++;
            }
        }
        
        
        
        
        
        
        /*                                   /
         /                                   /
         /      Ritningslägen för spelet     /
         /                                   /
         */                                  //
        
        
        //LÄGE 1 (inga skott)
        if(bulletActivate == 0 && bulletActivate2 == 0)
        {
            draw1(ship, ship2, enemies1, enemies2, enemies3, enemyBullet1, enemyBullet2, enemyBullet3, markerarIndex1, markerarIndex2, markerarIndex3, enemyBulletActivate1, enemyBulletActivate2, enemyBulletActivate3);
        }
        
        //Läge 2 (spleare 1 skott)
        if(bulletActivate == 1 && bulletActivate2 == 0)
        {
            draw2(ship, ship2, bullet, enemies1, enemies2, enemies3, enemyBullet1, enemyBullet2, enemyBullet3, markerarIndex1, markerarIndex2, markerarIndex3, enemyBulletActivate1, enemyBulletActivate2, enemyBulletActivate3);
            
            bullet.y -= 2;
        }
        
        //Läge 3 (spleare 2 skott)
        if(bulletActivate == 0 && bulletActivate2 == 1)
        {
            draw3(ship, ship2, bullet2, enemies1, enemies2, enemies3, enemyBullet1, enemyBullet2, enemyBullet3, markerarIndex1, markerarIndex2, markerarIndex3, enemyBulletActivate1, enemyBulletActivate2, enemyBulletActivate3);
            
            bullet2.y -= 2;
        }
        
        //Läge 4 (spleare 1 & 2 skott)
        if(bulletActivate == 1 && bulletActivate2 == 1)
        {
            draw4(ship, ship2, bullet, bullet2, enemies1, enemies2, enemies3, enemyBullet1, enemyBullet2, enemyBullet3, markerarIndex1, markerarIndex2, markerarIndex3, enemyBulletActivate1, enemyBulletActivate2, enemyBulletActivate3);
            
            bullet.y -= 2;
            bullet2.y -= 2;
        }
        
        
        
        
        /*
         /   FÖRFLYTTNING AV FIENDER
         */
        if (counter == 50)
        {
            counter1++;
            
            if (counter1 % 2 == 0)
            {
                int i = 0;
                while (i!=10)
                {
                    enemies1[i].x += 4;
                    enemies2[i].x += 4;
                    enemies3[i].x += 4;
                    i++;
                }
                
            }else
            {
                int i = 0;
                while (i!=10)
                {
                    enemies1[i].x -= 4;
                    enemies2[i].x -= 4;
                    enemies3[i].x -= 4;
                    i++;
                }
            }
            counter = 0;
        }
        
        counter++;
        delay(20);
        
        
        
        
        
        /*
         /   HP-SYSTEM
         */
        if(HP == 8)
        {
            PORTE = 0x0FF;
        }
        if(HP == 7)
        {
            PORTE = 0x07F;
        }
        if(HP == 6)
        {
            PORTE = 0x03F;
        }
        if(HP == 5)
        {
            PORTE = 0x01F;
        }
        if(HP == 4)
        {
            PORTE = 0x00F;
        }
        if(HP == 3)
        {
            PORTE = 0x07;
        }
        if(HP == 2)
        {
            PORTE = 0x03;
        }
        if(HP == 1)
        {
            PORTE = 0x01;
        }
        
        
        //Starta om spel när alla fiender är träffade
        if (enemiesHit == 30)
        {
            delay(50);
            twoPlayer();
        }
        
        
        /*
         /   SPELETS SLUT
         */
        if (HP == 0)
        {
            PORTE = 0x0;
            delay(600);
            
            hsArr[0] = highscore;
            
            while(1)
            {
                
                if (highscore == 0)
                {
                    break;
                }
                
                
                
                /*                      /
                 /                       /
                 /   HIGH-SCORE SYSTEM   /
                 /                       /
                 /*                      /
                 
                 
                 
                 /*
                 /   Jämför Score med FÖRSTAplats
                 */
                if (hsArr[1] > (score1[0] - '0'))
                {
                    
                    score3[0] = score2[0];
                    score3[1] = score2[1];
                    
                    score2[0] = score1[0];
                    score2[1] = score1[1];
                    
                    score1[0] = (hsArr[1] + '0');
                    score1[1] = (hsArr[0] + '0');
                    break;
                }
                
                if (hsArr[1] == (score1[0] - '0'))
                {
                    if (hsArr[0] > (score1[1] - '0'))
                    {
                        
                        score3[0] = score2[0];
                        score3[1] = score2[1];
                        
                        score2[0] = score1[0];
                        score2[1] = score1[1];
                        
                        score1[0] = (hsArr[1] + '0');
                        score1[1] = (hsArr[0] + '0');
                        break;
                    }
                }
                
                
                
                /*
                 /   Jämför Score med ANDRAplats
                 */
                if (hsArr[1] > (score2[0] - '0'))
                {
                    score3[0] = score2[0];
                    score3[1] = score2[1];
                    
                    score2[0] = (hsArr[1] + '0');
                    score2[1] = (hsArr[0] + '0');
                    break;
                }
                
                if (hsArr[1] == (score2[0] - '0'))
                {
                    if (hsArr[0] > (score2[1] - '0'))
                    {
                        score3[0] = score2[0];
                        score3[1] = score2[1];
                        
                        score2[0] = (hsArr[1] + '0');
                        score2[1] = (hsArr[0] + '0');
                        break;
                    }
                }
                
                
                
                /*
                 /   Jämför Score med TREDJEplats
                 */
                if (hsArr[1] > (score3[0] - '0'))
                {
                    score3[0] = (hsArr[1] + '0');
                    score3[1] = (hsArr[0] + '0');
                    break;
                }
                
                if (hsArr[1] == (score3[0] - '0'))
                {
                    if (hsArr[0] > (score3[1] - '0'))
                    {
                        score3[0] = (hsArr[1] + '0');
                        score3[1] = (hsArr[0] + '0');
                        break;
                    }
                }
                
            }
            
            while(1)
            {
                renderScreen(gameOver);
                int btn2 = getbtns();
                
                if(btn2 == 2)
                {
                    delay(500);
                    break;
                }
                HP = 8;
            }
            break;
        }
        
    }
    
}




void menu()
{
    HP = 8;
    highscore = 0;
    hsArr[0] = 0;
    hsArr[1] = 0;
    
    
    
    while(1)
    {
        int btn = getbtns();
        renderScreen(menu1);
        
        if(btn == 1)
        {
            delay(100);
            break;
        }
        
        if(btn == 2)
        {
            HP = 8;
            highscore = 0;
            hsArr[0] = 0;
            hsArr[1] = 0;
            delay(300);
            
            onePlayer();
        }
    }
    
    while(1)
    {
        int btn = getbtns();
        renderScreen(menu2);
        
        if(btn == 1)
        {
            delay(100);
            break;
        }
        
        if(btn == 2)
        {
            HP = 8;
            highscore = 0;
            hsArr[0] = 0;
            hsArr[1] = 0;
            delay(300);
            
            twoPlayer();
        }
    }
    
    while(1)
    {
        int btn = getbtns();
        renderScreen(menu3);
        
        if(btn == 1)
        {
            delay(100);
            menu();
        }
        
        if(btn == 2)
        {
            delay(200);
            while(1)
            {
                display_update();
                display_string(0, "HIGH-SCORE");
                display_string(1, score1);
                display_string(2, score2);
                display_string(3, score3);
                
                int btns = getbtns();
                if (btns == 2)
                {
                    delay(200);
                    menu();
                }
            }
        }
    }
}
